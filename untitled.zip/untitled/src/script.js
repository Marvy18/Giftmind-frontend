const generateBtn = document.getElementById("generateBtn");
const recommendations = document.getElementById("recommendations");
const profileCard = document.getElementById("profileCard");

generateBtn.addEventListener("click", () => {
  const relationship =
    document.getElementById("relationship").value;

  profileCard.classList.remove("hidden");

  let gifts = [];

  if (relationship === "Father") {
    gifts = [
      {
        title: "5 SOL Savings Gift",
        reason:
          "Long-term value and financial growth."
      },
      {
        title: "Educational NFT",
        reason:
          "Encourages learning and future opportunities."
      }
    ];
  } else if (relationship === "Boyfriend") {
    gifts = [
      {
        title: "1-of-1 Art NFT",
        reason:
          "Matches Zara's digital art interests."
      },
      {
        title: "Music Festival NFT",
        reason:
          "Reflects her love for music and travel."
      }
    ];
  } else {
    gifts = [
      {
        title: "Personalized NFT",
        reason:
          "Based on her interests and wallet activity."
      },
      {
        title: "2 SOL Gift",
        reason:
          "Useful and flexible digital asset."
      }
    ];
  }

  recommendations.innerHTML =
    "<h2>AI Recommendations</h2>";

  gifts.forEach((gift) => {
    recommendations.innerHTML += `
      <div class="gift-card">
        <h3>${gift.title}</h3>
        <p>${gift.reason}</p>
        <button onclick="alert('Connect Phantom Wallet')">
          Send Gift
        </button>
      </div>
    `;
  });

  recommendations.classList.remove("hidden");
});